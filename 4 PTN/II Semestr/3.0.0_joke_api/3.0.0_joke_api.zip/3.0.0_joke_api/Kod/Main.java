import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static int iloscKawalow;
    static int i = 0;
    static int wybor;
    static int wyborUstawienia;
    static int wyborKategorie;
    static int wyborJezyka;
    static int wyborFlaga;
    static int wyborTyp;
    static String[] kategorie = {"Programming", "Misc", "Dark", "Pun", "Spooky", "Christmas"};
    static String[] jezyki = {"cz - Czech", "de - German", "en - English", "es - Spanish", "fr - French", "pt - Portuguese"};
    static String[] flags = {"NSFW", "Religious", "Political", "Racist", "Sexist", "Explicit"};
    static String[] typ = {"Single", "Two Part"};
    
    public static void main(String[] args) {
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://v2.jokeapi.dev/joke/Any?format=txt"))
            .GET()
            .build();

        try {
            do {
                System.out.println("\n-------------Menu-------------");
                System.out.println("1 - Wyświetl losowy kawał\n2 - Wyświetl kawał według ustawień\n3 - Ustawienia\n4 - Zakończ");
                System.out.print("Wybór: ");
                wybor = sc.nextInt();

                if (wybor == 1) {
                    System.out.println("\n-------------Wyświetl-losowy-kawał------------\n");
                    System.out.print("Ile kawałów sobie życzysz (max 10) | ");
                    iloscKawalow = sc.nextInt();
    
                    if (iloscKawalow < 11) {
                        for (int i = 1; i <= iloscKawalow; i++) {
                            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                            String responseBody = response.body();
                            System.out.println("\n" + i + ". " + responseBody + "\n-------------------------------------------");
                        }                    
                    } else { System.out.println("Maksymalnie 10 kawałów."); }
                } else if (wybor == 2) {
                    System.out.println("\n-------------Wyświetl-kawał-według-ustawień------------\n");
                } else if (wybor == 3) {
                    do {
                        System.out.println("\n-------------Ustawienia--------------\n");
                        System.out.println("1 - Kategoria\n2 - Język\n3 - Flags\n4 - Typ\n5 - Cofnij");
                        System.out.print("Wybór: ");
                        wyborUstawienia = sc.nextInt();
                        if (wyborUstawienia == 1) {
                            System.out.println("\n-------------Kategoria------------\n");
                            System.out.println("Wybierz kategorie z podanych poniżej, używając numeru");
                            for (int i = 0; i < kategorie.length; i++) {
                                i += 1;
                                System.out.print(i + ". ");
                                i -= 1;
                                System.out.print(kategorie[i] + "\n");
                            }
                            System.out.print("Podaj numer kategorii: ");
                            wyborKategorie = sc.nextInt();
                        } else if (wyborUstawienia == 2) {
                            System.out.println("\n-------------Język------------\n");
                            System.out.println("Wybierz język z podanych poniżej, używając numeru");
                            for (int i = 0; i < jezyki.length; i++) {
                                i += 1;
                                System.out.print(i + ". ");
                                i -= 1;
                                System.out.print(jezyki[i] + "\n");
                            }
                            System.out.print("Podaj numer języka: ");
                            wyborJezyka = sc.nextInt();
                        } else if (wyborUstawienia == 3) {
                            System.out.println("\n-------------Flags------------\n");
                            System.out.println("Wybierz flags z podanych poniżej, używając numeru");
                            for (int i = 0; i < flags.length; i++) {
                                i += 1;
                                System.out.print(i + ". ");
                                i -= 1;
                                System.out.print(flags[i] + "\n");
                            }
                            System.out.print("Podaj numer flags: ");
                            wyborFlaga = sc.nextInt();
                        } else if (wyborUstawienia == 4) {
                            System.out.println("\n-------------Typ------------\n");
                            System.out.println("Wybierz flags z podanych poniżej, używając numeru");
                            for (int i = 0; i < typ.length; i++) {
                                i += 1;
                                System.out.print(i + ". ");
                                i -= 1;
                                System.out.print(typ[i] + "\n");
                            }
                            System.out.print("Podaj numer typu: ");
                            wyborTyp = sc.nextInt();
                        } else {
                            System.out.println("Zły numer...");
                        }
                    } while (wyborUstawienia!= 5);
                } else if (wybor == 4) {
                    System.out.println("\n-------------Zakończ--------------\nI żyli długo i szczęśliwie");

                } else {
                    System.out.println("\n-------------------------------------------\nZły numer...");
                }
            } while (wybor != 4);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}